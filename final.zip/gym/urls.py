from django.urls import path

from . import views

urlpatterns = [

    path('', views.home),

    # ---------- مسیرهای استاد ----------

    path(
        'coach-login/',
        views.coach_login,
        name='coach_login'
    ),

    path(
        'coach-logout/',
        views.coach_logout,
        name='coach_logout'
    ),

    path(
        'coach-dashboard/',
        views.coach_dashboard,
        name='coach_dashboard'
    ),

    path(
        'paid-students/',
        views.paid_students,
        name='paid_students'
    ),

    path(
        'unpaid-students/',
        views.unpaid_students,
        name='unpaid_students'
    ),

    path(
        'monthly-report/',
        views.monthly_report,
        name='monthly_report'
    ),

    path(
        'add-student/',
        views.add_student,
        name='add_student'
    ),

    path(
        'edit-coach-info/',
        views.edit_coach_info,
        name='edit_coach_info'
    ),

    path(
        'delete-student/<int:student_id>/',
        views.delete_student,
        name='delete_student'
    ),

    path(
        'update-settings/',
        views.update_settings,
        name='update_settings'
    ),

    # ---------- مسیرهای شاگرد ----------

    path(
        'student-login/',
        views.student_login,
        name='student_login'
    ),

    path(
        'student-dashboard/',
        views.student_dashboard,
        name='student_dashboard'
    ),

    path(
        'logout/',
        views.student_logout,
        name='logout'
    ),

    path(
        'coach-info/',
        views.coach_info,
        name='coach_info'
    ),

    path(
        'pay-fee/',
        views.pay_fee,
        name='pay_fee'
    ),

]
