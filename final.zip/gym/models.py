from django.db import models
from django.contrib.auth.models import User


class Student(models.Model):

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )

    full_name = models.CharField(max_length=100)

    national_code = models.CharField(
        max_length=10,
        unique=True,
        null=True,
        blank=True
    )

    phone = models.CharField(max_length=20)

    join_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.full_name
    

class Coach(models.Model):

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )

    full_name = models.CharField(max_length=100)

    phone = models.CharField(max_length=20)

    email = models.EmailField()

    def __str__(self):
        return self.full_name

class Payment(models.Model):

    student = models.ForeignKey(
        Student,
        on_delete=models.CASCADE
    )

    amount = models.IntegerField()

    month = models.CharField(max_length=20)

    payment_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.full_name} - {self.month}"


class GymSettings(models.Model):

    monthly_fee = models.IntegerField(
        default=0
    )

    card_number = models.CharField(
        max_length=20,
        blank=True
    )

    card_owner_name = models.CharField(
        max_length=100,
        blank=True
    )

    def __str__(self):
        return f"شهریه: {self.monthly_fee} - کارت: {self.card_number}"
    
