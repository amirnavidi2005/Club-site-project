from collections import defaultdict

from .models import Payment
from .models import Student
from .models import Coach
from .models import GymSettings

from django.contrib.auth.models import User

from django.shortcuts import render

from django.contrib.auth.decorators import login_required

from django.contrib.auth import authenticate
from django.contrib.auth import login
from django.contrib.auth import logout
from django.shortcuts import redirect
from django.contrib import messages

PERSIAN_MONTHS = [
    'فروردین',
    'اردیبهشت',
    'خرداد',
    'تیر',
    'مرداد',
    'شهریور',
    'مهر',
    'آبان',
    'آذر',
    'دی',
    'بهمن',
    'اسفند',
]

def home(request):
    return render(request, 'home.html')

@login_required(login_url='coach_login')
def coach_dashboard(request):

    students = Student.objects.all()

    payments = Payment.objects.all()

    total_students = students.count()

    total_payments = payments.count()

    total_income = 0

    for payment in payments:

        total_income += payment.amount

    context = {

        'students': students,

        'total_students': total_students,

        'total_payments': total_payments,

        'total_income': total_income,

    }

    return render(
        request,
        'coach_dashboard.html',
        context
    )

@login_required(login_url='coach_login')
def paid_students(request):

    payments = []

    selected_month = ''

    if request.GET.get('month'):

        selected_month = request.GET.get('month')

        payments = Payment.objects.filter(
            month=selected_month
        )

    context = {

        'payments': payments,

        'selected_month': selected_month

    }

    return render(
        request,
        'paid_students.html',
        context
    )

@login_required(login_url='coach_login')
def unpaid_students(request):

    students = []

    selected_month = ''

    if request.GET.get('month'):

        selected_month = request.GET.get('month')

        paid_student_ids = Payment.objects.filter(
            month=selected_month
        ).values_list(
            'student_id',
            flat=True
        )

        students = Student.objects.exclude(
            id__in=paid_student_ids
        )

    context = {

        'students': students,

        'selected_month': selected_month

    }

    return render(
        request,
        'unpaid_students.html',
        context
    )

@login_required(login_url='coach_login')
def monthly_report(request):

    payments = Payment.objects.all()

    report = defaultdict(int)

    for payment in payments:

        report[payment.month] += payment.amount

    context = {
        'report': dict(report)
    }

    return render(
        request,
        'monthly_report.html',
        context
    )

@login_required(login_url='coach_login')
def add_student(request):

    if request.method == "POST":

        full_name = request.POST.get('full_name', '').strip()

        national_code = request.POST.get('national_code', '').strip()

        phone = request.POST.get('phone', '').strip()

        username = request.POST.get('username', '').strip()

        password = request.POST.get('password', '').strip()

        # ---------- اعتبارسنجی ورودی‌ها ----------

        if not full_name or not national_code or not phone or not username or not password:

            messages.error(
                request,
                'لطفاً همه‌ی فیلدها را پر کنید'
            )

            return render(request, 'add_student.html')

        if not national_code.isdigit() or len(national_code) != 10:

            messages.error(
                request,
                'کد ملی باید دقیقاً ۱۰ رقم و فقط شامل عدد باشد'
            )

            return render(request, 'add_student.html')

        if len(password) < 8:

            messages.error(
                request,
                'رمز عبور باید حداقل ۸ کاراکتر باشد'
            )

            return render(request, 'add_student.html')

        if User.objects.filter(username=username).exists():

            messages.error(
                request,
                'این نام کاربری قبلاً استفاده شده است'
            )

            return render(request, 'add_student.html')

        if Student.objects.filter(national_code=national_code).exists():

            messages.error(
                request,
                'شاگردی با این کد ملی قبلاً ثبت شده است'
            )

            return render(request, 'add_student.html')

        # ---------- ساخت کاربر و شاگرد ----------

        try:

            new_user = User.objects.create_user(
                username=username,
                password=password
            )

            Student.objects.create(
                user=new_user,
                full_name=full_name,
                national_code=national_code,
                phone=phone
            )

        except Exception as error:

            messages.error(
                request,
                f'خطایی رخ داد و شاگرد ثبت نشد: {error}'
            )

            return render(request, 'add_student.html')

        messages.success(
            request,
            'شاگرد جدید با موفقیت ثبت شد'
        )

        return redirect('coach_dashboard')

    return render(
        request,
        'add_student.html'
    )

@login_required(login_url='coach_login')
def delete_student(request, student_id):

    student = Student.objects.get(id=student_id)

    if request.method == "POST":

        if student.user:

            student.user.delete()

        student.delete()

        messages.success(
            request,
            'شاگرد با موفقیت حذف شد'
        )

        return redirect('coach_dashboard')

    return render(
        request,
        'delete_student_confirm.html',
        {'student': student}
    )

@login_required(login_url='coach_login')
def edit_coach_info(request):

    coach = Coach.objects.filter(
        user=request.user
    ).first()

    if coach is None:

        coach = Coach.objects.first()

    if request.method == "POST":

        full_name = request.POST.get('full_name', '').strip()

        phone = request.POST.get('phone', '').strip()

        email = request.POST.get('email', '').strip()

        if not full_name or not phone or not email:

            messages.error(
                request,
                'لطفاً همه‌ی فیلدها را پر کنید'
            )

            return render(
                request,
                'edit_coach_info.html',
                {'coach': coach}
            )

        try:

            coach.full_name = full_name

            coach.phone = phone

            coach.email = email

            coach.save()

        except Exception as error:

            messages.error(
                request,
                f'خطایی رخ داد و اطلاعات ذخیره نشد: {error}'
            )

            return render(
                request,
                'edit_coach_info.html',
                {'coach': coach}
            )

        messages.success(
            request,
            'اطلاعات استاد با موفقیت به‌روزرسانی شد'
        )

        return redirect('coach_dashboard')

    return render(
        request,
        'edit_coach_info.html',
        {'coach': coach}
    )

@login_required(login_url='coach_login')
def update_settings(request):

    settings_obj, created = GymSettings.objects.get_or_create(
        id=1
    )

    if request.method == "POST":

        settings_obj.monthly_fee = request.POST.get('monthly_fee')

        settings_obj.card_number = request.POST.get('card_number')

        settings_obj.card_owner_name = request.POST.get('card_owner_name')

        settings_obj.save()

        messages.success(
            request,
            'مبلغ شهریه و شماره کارت با موفقیت ثبت شد'
        )

        return redirect('coach_dashboard')

    context = {
        'settings_obj': settings_obj
    }

    return render(
        request,
        'update_settings.html',
        context
    )

def coach_login(request):

    error_message = ''

    if request.method == "POST":

        username = request.POST.get('username')

        password = request.POST.get('password')

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:

            is_coach = Coach.objects.filter(user=user).exists()

            if is_coach:

                login(request, user)

                return redirect('coach_dashboard')

            else:

                error_message = 'این حساب کاربری متعلق به استاد نیست'

        else:

            error_message = 'نام کاربری یا رمز عبور اشتباه است'

    return render(
        request,
        'coach_login.html',
        {'error_message': error_message}
    )

def student_login(request):

    error_message = ''

    if request.method == "POST":

        username = request.POST.get('username')

        password = request.POST.get('password')

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:

            is_student = Student.objects.filter(user=user).exists()

            if is_student:

                login(request, user)

                return redirect('student_dashboard')

            else:

                error_message = 'این حساب کاربری متعلق به شاگرد نیست'

        else:

            error_message = 'نام کاربری یا رمز عبور اشتباه است'

    return render(
        request,
        'student_login.html',
        {'error_message': error_message}
    )

@login_required
def student_dashboard(request):

    student = Student.objects.get(
        user=request.user
    )

    payments = Payment.objects.filter(
        student=student
    )

    total_paid = 0

    for payment in payments:

        total_paid += payment.amount

    context = {

        'student': student,

        'payments': payments,

        'total_paid': total_paid

    }

    return render(
        request,
        'student_dashboard.html',
        context
    )

def student_logout(request):

    logout(request)

    return redirect('student_login')

@login_required
def pay_fee(request):

    student = Student.objects.get(
        user=request.user
    )

    settings_obj, created = GymSettings.objects.get_or_create(
        id=1
    )

    if request.method == "POST":

        selected_month = request.POST.get('month')

        already_paid = Payment.objects.filter(
            student=student,
            month=selected_month
        ).exists()

        if already_paid:

            messages.error(
                request,
                'شهریه این ماه قبلاً پرداخت شده است'
            )

        else:

            Payment.objects.create(
                student=student,
                amount=settings_obj.monthly_fee,
                month=selected_month
            )

            messages.success(
                request,
                f'پرداخت شهریه ماه {selected_month} با موفقیت ثبت شد'
            )

        return redirect('pay_fee')

    paid_months = Payment.objects.filter(
        student=student
    ).values_list(
        'month',
        flat=True
    )

    month_status = []

    for month_name in PERSIAN_MONTHS:

        month_status.append({

            'name': month_name,

            'is_paid': month_name in paid_months,

        })

    context = {

        'months': PERSIAN_MONTHS,

        'settings_obj': settings_obj,

        'month_status': month_status,

    }

    return render(
        request,
        'pay_fee.html',
        context
    )

def coach_logout(request):

    logout(request)

    return redirect('coach_login')

@login_required
def coach_info(request):

    coach = Coach.objects.first()

    context = {
        'coach': coach
    }

    return render(
        request,
        'coach_info.html',
        context
    )