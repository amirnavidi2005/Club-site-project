from django.contrib import admin

from .models import Student
from .models import Coach
from .models import Payment
from .models import GymSettings

admin.site.register(Student)
admin.site.register(Coach)
admin.site.register(Payment)
admin.site.register(GymSettings)